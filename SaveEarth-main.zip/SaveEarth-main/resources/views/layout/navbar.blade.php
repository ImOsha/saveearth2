<link rel="stylesheet" href="css/bootstrap.css">
<nav class="navbar navbar-expand-lg bg-body-tertiary border-bottom border-success fixed-top" style="background-color:#19406C;">
  <div class="container-fluid">
    <img src="SaveEarthLogo.png" style="width:40px; ">
    <a class="navbar-brand">SaveEarth</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link" href="/beranda">Beranda</a>
        <a class="nav-link" href="/katalog">Katalog</a>
        <a class="nav-link" href="/kalkulatorkarbon">Kalkulator Karbon</a>
        <a class="nav-link" href="/donasi">Donasi</a>
      </div>
    </div>
  </div>
</nav>
 <div class="container-fluid bg-body-tertiary border-top border-success d-flex flex-column" style="background-color:#19406C;">
<h6 class="text-center text-white">Copyright © 2024 SaveEarth|All rights reserved</h6>
<h6 class="text-center text-white">This website is just for study purposes and features such as donations are not real</h6>
  </div>
<link rel="stylesheet" href="information.css">
@include('layout.navbar')
{{-- <body style="background-image:linear-gradient(#44FC3E, #FFFFFF);"> --}}
    <div class="image-container">
    <a href="/ceritapohon" class="image-button"><img src="CeritaPohonCover.png"></a>
    <a href="/bagaimana" class="image-button"><img src="GlobalWarmingCover.png"></a>
    <a href=# class="image-button"><img src="defaultcover.jpg"></a>
    </div>
{{-- </body> --}}

